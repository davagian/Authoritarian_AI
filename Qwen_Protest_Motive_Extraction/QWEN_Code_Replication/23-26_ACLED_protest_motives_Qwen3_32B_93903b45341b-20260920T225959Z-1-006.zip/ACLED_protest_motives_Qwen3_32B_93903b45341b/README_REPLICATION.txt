ACLED PROTEST MOTIVE CODING — REPLICATION ARCHIVE
=================================================

MODEL
-----
Model: Qwen/Qwen3-32B
Exact Hugging Face revision:
9216db5781bf21249d130ec9da846c4624c16137

QUANTIZATION
------------
4-bit NF4 via bitsandbytes
Double quantization: yes
Compute dtype: torch.bfloat16

INFERENCE
---------
Qwen thinking mode: disabled
Sampling: disabled
Decoding: greedy
Max new tokens: 180
Seed: 12345

INPUT DATA
----------
Filename:
ACLED Data_2026-09-20_event_date_from_2023-01-01_event_date_to_2026-09-20.csv

SHA256:
a795fcd65ccbc016956787f825e505d4ec30c5321234fd3219c8cf226e63fb42

Number of source observations:
1071

Text field:
notes

Event identifier:
event_id_cnty

OUTPUT VARIABLES
----------------
abstract_motive:
Generalized description of the main protest grievance or demand.

specific_motive:
Event-specific description of the grievance or demand.

secondary_motives_json:
Additional explicitly stated motives.

evidence:
Short exact passage from the source description supporting the coding.

uncertain:
Whether the description is insufficient or ambiguous.

parse_ok:
Whether the model response could be parsed as valid JSON.

raw_model_response:
Unmodified output produced by Qwen.

REPLICATION FILES
-----------------
input/
    Original ACLED input file.

model/
    Exact 4-bit checkpoint and tokenizer, if checkpoint archiving
    was enabled.

metadata/coding_prompt.txt
    Exact coding instructions.

metadata/model_and_run_metadata.json
    Model, quantization, generation, software, hardware and
    data settings.

metadata/pip_freeze.txt
    Complete package environment from the actual run.

metadata/runtime_environment.txt
    Runtime and GPU information.

metadata/file_checksums.csv
    SHA256 hashes of major files.

metadata/model_file_checksums.csv
    SHA256 hashes of model files, if archived.

results/raw_model_outputs.jsonl
    Observation-level raw model output.

results/ACLED_protests_with_Qwen3_motives.csv
    Final coded dataset.

results/ACLED_protests_with_Qwen3_motives.parquet
    Equivalent Parquet version.

RUN FINGERPRINT
---------------
93903b45341b